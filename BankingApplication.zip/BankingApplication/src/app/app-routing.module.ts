import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './create-account/create-account.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionsComponent } from './print-transactions/print-transactions.component';


const routes: Routes = [
  {path : 'CreateAccount',component:CreateAccountComponent},
  {path : 'Deposit',component:DepositComponent},
  {path : 'Withdraw',component:WithdrawComponent},
  {path : 'ShowBalance',component:ShowBalanceComponent},
  {path : 'FundTransfer',component:FundTransferComponent},
  {path : 'PrintTransactions',component:PrintTransactionsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
